This version was compiled without the -e (GAPING_SECURITY_HOLE) option which can trigger anti-virus programs false positives.


makewin.cmd is the script that was used to compile.


Build Environment:
	Gcc 3.4.5 (MinGW version 5.1.4)
	Windows 7 Ultimate 64-bit RC build 7100


Original NT version comes from http://joncraton.org/blog/46#disqus_thread


Rodney Beede
http://www.rodneybeede.com/
contactme@rodneybeede.com